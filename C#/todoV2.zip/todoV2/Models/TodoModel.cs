﻿namespace todoV2.Models
{
    public class TodoModel
    {

    }
}
