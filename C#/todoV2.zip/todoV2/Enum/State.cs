public enum State
{
  Todo = 1,
  Doing = 2,
  Done = 3
}