﻿namespace todoV2.Constant
{
    public static class CoockiesSessionsKeys
    {
        public static readonly string themeCoockie = "theme";
    }
}
