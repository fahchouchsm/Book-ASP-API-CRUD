﻿namespace todoV2.Constant
{
    public static class LoggerFilterKeys
    {
        public const string deleteTodo = "delteTodo";
        public const string addTodo = "addTodo";
        public const string editTodo = "editTodo";
    }
}
