﻿using Microsoft.AspNetCore.Mvc;
using todoV2.ViewModels;
using todoV2.data;
using todoV2.Mappers;
using todoV2.Services.SessionManager;
using todoV2.Filters;
using todoV2.Services.Auth;
using todoV2.Constant;
using System.Text.Json;

namespace todoV2.Controllers
{
    [LoggerFilter]
    public class TodoController : Controller
    {
        private readonly ISessionManagerService _sessionManager;
        private readonly IAuthService _authService;

        public TodoController(ISessionManagerService sessionManagerService, IAuthService auth)
        {
            this._sessionManager = sessionManagerService;
            this._authService = auth;
        }

        public IActionResult Index()
        {
            List<Todo> todos = _sessionManager.getFromSession<List<Todo>>("todos") ?? new List<Todo>();
            ViewBag.todos = todos;
            ViewBag.auth = _authService.isAuth();
            return View();
        }

        [HttpPost]
        public IActionResult EditTodo(TodoEditVm vm)
        {
            if(!ModelState.IsValid)
            {
                return RedirectToAction("Index");
            }
            Todo todo = TodoMapper.getTodoFromTodoEditVM(vm);
            //List<Todo> listFromSession = _sessionManager.getFromSession<List<Todo>>("todos")!;
            string json = HttpContext.Session.GetString("todos");
            List<Todo> ls = JsonSerializer.Deserialize<List<Todo>>(json);

            for (int i = 0; i < ls.Count; i++)
            {
                if(ls[i].id == vm.id)
                {
                    ls[i] = todo;
                    break;
                }
            }
            //_sessionManager.addSession(listFromSession, "todos");
            string lsJson = JsonSerializer.Serialize(ls);
            HttpContext.Session.SetString("todos", lsJson);
            HttpContext.Items[LoggerFilterKeys.editTodo] = todo;
            return RedirectToAction(nameof(Index));
        }

        [HttpPost]
        public IActionResult AddTodo(TodoAddVm vm)
        {
            if (!ModelState.IsValid)
            {
                return View("Index", vm);
            }
            List<Todo> todos = new List<Todo>();
            Todo todo = TodoMapper.getTodoFromTodoAddVM(vm);

            var json = HttpContext.Session.GetString("todos");
            if (json != null)
            {
                List<Todo> ls = JsonSerializer.Deserialize<List<Todo>>(json);
                int idKbira = todos.Max(t => t.id);
                todo.id = idKbira + 1;
                todos.Add(todo);

                //todos = _sessionManager.getFromSession<List<Todo>>("todos")!;
                //todo.id = todos.Any() ? todos.Max(t => t.id) + 1 : 1 ;
                _sessionManager.addSession(todos, "todos");
            }
            else
            {
                todo.id = 1;
                todos.Add(todo);
                _sessionManager.addSession(todos, "todos");
            }

            HttpContext.Items["adding"] = todo;

            return RedirectToAction(nameof(TodoController.Index));
        }

        [TypeFilter(typeof(AuthFilter))]
        [HttpPost]
        public IActionResult DeleteTodo(int id)
        {
            if (id <= 0)
            {
                return BadRequest();
            }



            List<Todo> todos = _sessionManager.getFromSession<List<Todo>>("todos") ?? new List<Todo>();
            //Todo todo = todos.Find(t => t.id == id)!;
            for (int i = 0; i < todos.Count; i++)
            {
                if (todos[i].id == id)
                {
                    todos.Remove(todos[i]);
                    break;
                } 
            }
            //if (todo == null)
            //{
            //    return NotFound();
            //}
            //todos.Remove(todo);
            _sessionManager.addSession(todos, "todos");

            HttpContext.Items[LoggerFilterKeys.deleteTodo] = todo;
            return RedirectToAction(nameof(TodoController.Index));
        }
    }
}
