public interface I2prime {
    static void x() {
        System.out.println("Bonsoir");
    }
}
