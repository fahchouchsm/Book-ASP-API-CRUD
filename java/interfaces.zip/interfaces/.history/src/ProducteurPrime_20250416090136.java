public class ProducteurPrime {

}
