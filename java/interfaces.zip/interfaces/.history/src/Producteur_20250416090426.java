public class Producteur {
    private double nbu;

    public double calcSalaire() {
        return nbu * 10;
    }

    public void afficherSalaire() {
        System.out.println("Le salaire du producteur est : " + calcSalaire());
    }
}
