public interface Iprime {
    double prime = 2000;

    static void x() {
        System.out.println("Bonjour");
    }
}
