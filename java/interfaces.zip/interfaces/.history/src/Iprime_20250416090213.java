public interface Iprime {
    double prime = 2000;
}
