public class App {
    public static void main(String[] args) throws Exception {
        Producteur p = new Producteur(100);
        p.afficherSalaire();
        ProducteurPrime pPrime = new ProducteurPrime(100);
        pPrime.afficherSalaire();
    }
}
