public class producteur {
    private double nbu;

    public double calcSalaire() {
        return nbu * 10;
    }
}
