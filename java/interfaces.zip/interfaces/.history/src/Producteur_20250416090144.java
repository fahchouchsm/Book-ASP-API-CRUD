public class Producteur {
    private double nbu;

    public double calcSalaire() {
        return nbu * 10;
    }
}
