public class App {
    public static void main(String[] args) throws Exception {
        Producteur p = new Producteur(100);
        p.afficherSalaire();
        ProducteurPrime pp = new ProducteurPrime(100);
        pp.afficherSalaire();
    }
}
