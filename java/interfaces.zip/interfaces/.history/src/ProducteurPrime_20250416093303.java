public class ProducteurPrime extends Producteur implements Iprime {

    public ProducteurPrime(double nbu) {

        super(nbu);
    }

    public double calcSalaire() {
        return super.calcSalaire() + prime;
    }

}
