public interface Iprime {
    double prime = 2000;

    default void x() {
        System.out.println("Bonjour");
    }
}
