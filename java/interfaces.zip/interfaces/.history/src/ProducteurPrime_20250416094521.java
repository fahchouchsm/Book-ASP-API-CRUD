public class ProducteurPrime extends Producteur {

    public ProducteurPrime(double nbu) {
        super(nbu);
    }

    public double calcSalaire() {
        return super.calcSalaire() + Iprime.prime;
    }
}