public interface Iprime {

}
