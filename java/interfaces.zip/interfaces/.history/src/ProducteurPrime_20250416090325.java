public class ProducteurPrime extends Producteur implements Iprime {
    public double calcSalaire() {
        return super.calcSalaire() + prime;
    }
}
