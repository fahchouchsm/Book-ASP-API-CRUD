public class ProducteurPrime extends Producteur implements Iprime {

    public ProducteurPrime(double nbu) {
        super(nbu);
    }

    public double calcSalaire() {
        return super.calcSalaire() + prime;
    }

    @Override
    public void afficherSalaire() {
        System.out.println("Le salaire du producteur Prime est : " + calcSalaire());

    }
}
