public interface I2prime {
    default void x() {
        System.out.println("Bonsoir");
    }
}
