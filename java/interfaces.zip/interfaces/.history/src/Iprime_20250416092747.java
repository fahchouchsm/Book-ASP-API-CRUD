public interface Iprime {
    double prime;
}
