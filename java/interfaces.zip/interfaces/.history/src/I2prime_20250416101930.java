public interface I2prime {
}
