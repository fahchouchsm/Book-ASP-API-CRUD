#include "employe.cpp"

int main() {
  Employe::afficher();
  return 0;
}