#include <iostream>
#include "pile.h"

using namespace std;

int main()
{
    Pile p(5);

    // Empiler des éléments
    p.empile(10);
    p.empile(20);
    p.empile(30);
    p.empile(40);
    p.empile(50);
    p.empile(60); // ❌ Pile pleine

    p.afficherP();
    cout << endl;

    // Dépiler des éléments
    p.depile();
    p.depile();
    p.afficherP();
    cout << endl;

    // Vider la pile
    while (!p.vide())
        p.depile();
    p.afficherP();
    cout << endl;

    p.depile(); // ❌ Pile vide

    return 0;
}
