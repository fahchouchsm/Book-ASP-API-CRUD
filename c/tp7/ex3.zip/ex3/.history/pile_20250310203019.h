#ifndef Pile H
#define Pile H
class Pile
{
public:
    Pile(int t = 10);
    ~Pile();
    void empile(int);
    void depile();
    bool vide() const;
    bool pleine() const;
    int donnetaille() const;

private:
    int dim;
    int taille;
    int *adr;
};
#endif