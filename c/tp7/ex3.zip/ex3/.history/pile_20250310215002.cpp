#include <iostream>
#include "pile.h"

using namespace std;

Pile::Pile(int n)
{
    dim = n;
    adr = new int[dim];
    taille = 0;
}

Pile::~Pile()
{
    delete[] adr;
}

bool Pile::vide() const
{
    if (taille == 0)
    {
        return true;
    }
    return false;
}

void Pile::empile(int p)
{
    if (pleinne() == false)
    {
        adr[taille] = p;
        taille++;
    }
    else
    {
        cout << "Impossible d'empiler la Pile est pleinne" << endl;
    }
}

void Pile::depile()
{
    if (vide() == false)
    {
        taille--;
    }
    else
    {
        cout << "Impossible de depiler Pile vide" << endl;
    }
}

void Pile::afficherP() const
{
    int i;
    if (vide() == false)
    {
        for (i = 0; i < taille; i++)
        {
            cout << " " << adr[i] << " ";
        }
    }
}