#include "pile.h"
#include <iostream>

using namespace std;

Pile::Pile(int t)
{
    adr = new int[t];
    dim = t;
    taille = 0;
};

Pile::~Pile()
{
    delete[] adr;
};

bool Pile::pleine() const
{
    if (taille > dim)
    {
        return true;
    }
    return false;
}

void Pile::empile(int n)
{
    if (taille > dim)
    {
        cout << "le tableau est plein!" << endl;
    }
    else
    {
        adr[taille] = n;
        taille++;
    }
};