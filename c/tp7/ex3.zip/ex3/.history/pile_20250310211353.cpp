#include "pile.h"
#include <iostream>

using namespace std;

Pile::Pile(int t)
{
    adr = new int[t];
}