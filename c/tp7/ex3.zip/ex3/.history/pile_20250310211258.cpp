#include "pile.h"
#include <iostream>

using namespace std;

Pile::Pile()
{
}