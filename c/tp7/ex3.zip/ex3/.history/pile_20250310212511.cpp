#include "pile.h"
#include <iostream>

using namespace std;

Pile::Pile(int t)
{
    adr = new int[t];
    dim = t;
    taille = 1;
};

Pile::~Pile()
{
    delete[] adr;
};

void Pile::empile(int n)
{
    if (taille > dim)
    {
        /* code */
    }
    else
    {

        adr[taille] = n;
        taille++;
    }
};