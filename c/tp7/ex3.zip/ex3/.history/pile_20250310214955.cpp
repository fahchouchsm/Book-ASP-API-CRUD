#include <iostream>
#include "pile.h"

using namespace std;

Pille::Pille(int n)
{
    dim = n;
    adr = new int[dim];
    taille = 0;
}

Pille::~Pille()
{
    delete[] adr;
}

bool Pille::vide() const
{
    if (taille == 0)
    {
        return true;
    }
    return false;
}

void Pille::empile(int p)
{
    if (pleinne() == false)
    {
        adr[taille] = p;
        taille++;
    }
    else
    {
        cout << "Impossible d'empiler la pille est pleinne" << endl;
    }
}

void Pille::depile()
{
    if (vide() == false)
    {
        taille--;
    }
    else
    {
        cout << "Impossible de depiler Pille vide" << endl;
    }
}

void Pille::afficherP() const
{
    int i;
    if (vide() == false)
    {
        for (i = 0; i < taille; i++)
        {
            cout << " " << adr[i] << " ";
        }
    }
}