#include <iostream>
#include "Vecteur.h"

using namespace std;
int main()
{
    // Create instances of Vecteur
    Vecteur v1(1.0, 2.0, 3.0);
    Vecteur v2(4.0, 5.0, 6.0);

    // Test addition
    Vecteur v3 = v1 + v2;
    cout << "v1 + v2 = " << v3 << endl;

    // Test subtraction
    Vecteur v4 = v1 - v2;
    cout << "v1 - v2 = " << v4 << endl;

    // Test dot product
    double dotProduct = v1.dot(v2);
    cout << "v1 . v2 = " << dotProduct << endl;

    // Test cross product
    Vecteur v5 = v1.cross(v2);
    cout << "v1 x v2 = " << v5 << endl;

    // Test magnitude
    double magnitude = v1.magnitude();
    cout << "Magnitude of v1 = " << magnitude << endl;

    // Test normalization
    Vecteur v6 = v1.normalize();
    cout << "Normalized v1 = " << v6 << endl;

    return 0;
}