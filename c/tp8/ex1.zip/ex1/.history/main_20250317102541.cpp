#include <iostream>
#include "Vecteur.h"

int main()
{
    // Create instances of Vecteur
    Vecteur v1(1.0, 2.0, 3.0);
    Vecteur v2(4.0, 5.0, 6.0);

    // Test addition
    Vecteur v3 = v1 + v2;
    std::cout << "v1 + v2 = " << v3 << std::endl;

    // Test subtraction
    Vecteur v4 = v1 - v2;
    std::cout << "v1 - v2 = " << v4 << std::endl;

    // Test dot product
    double dotProduct = v1.dot(v2);
    std::cout << "v1 . v2 = " << dotProduct << std::endl;

    // Test cross product
    Vecteur v5 = v1.cross(v2);
    std::cout << "v1 x v2 = " << v5 << std::endl;

    // Test magnitude
    double magnitude = v1.magnitude();
    std::cout << "Magnitude of v1 = " << magnitude << std::endl;

    // Test normalization
    Vecteur v6 = v1.normalize();
    std::cout << "Normalized v1 = " << v6 << std::endl;

    return 0;
}