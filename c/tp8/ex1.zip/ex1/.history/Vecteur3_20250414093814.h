#ifndef VECTEUR_H
#define VECTEUR_H
#include "Vecteur.h"

class Vecteur3 : public Vecteur
{
private:
    float h;

public:
    void initialise3(const float x, const float y, const float z, const float h);
    void afficher();
};
#endif