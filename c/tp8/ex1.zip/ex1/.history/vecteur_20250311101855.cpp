#include "vecteur.h"
#include <iostream>

using namespace std;

Vecteur::Vecteur(int x, int y, int z)
{
    this->x = x;
    this->y = y;
    this->z = z;
};