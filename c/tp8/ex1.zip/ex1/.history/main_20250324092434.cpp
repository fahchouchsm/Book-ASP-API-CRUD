#include "Vecteur.h"
#include <iostream>

using namespace std;

int main()
{
    // declaration
    Vecteur a, *b;
    // initialisation a la declaration au cours de creation
    Vecteur c = a;
    b = new Vecteur(3, 3, 2, "f");
    a = c;
    delete b;
    return 0;
}
