#include "Vecteur.h"
#include <iostream>

using namespace std;

int main()
{
    // declaration
    Vecteur a, *b;

    a.affiche();
    b = new Vecteur(1, 2, 3);

    if (b->compare(a))
    {
        cout << "egalite" << endl;
    }
    else
    {
        cout << "differant" << endl;
    }

    delete b;
    return 0;
}
