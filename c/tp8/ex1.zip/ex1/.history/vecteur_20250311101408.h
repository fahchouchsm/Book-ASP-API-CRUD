#ifndef VECTEUR_H
#define VECTEUR_H

class vecteur
{
};

#endif
