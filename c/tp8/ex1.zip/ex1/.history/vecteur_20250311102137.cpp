#include "vecteur.h"
#include <iostream>

using namespace std;

Vecteur::nbrVecteur = 0;

Vecteur::Vecteur(float x, float y, float z)
{
    this->x = x;
    this->y = y;
    this->z = z;
    nbrVecteur++;
};