#include "vecteur.h"
#include <iostream>

using namespace std;

int Vecteur::nbrVecteur = 0;

Vecteur::Vecteur(float x, float y, float z)
{
    this->x = x;
    this->y = y;
    this->z = z;
    nbrVecteur++;
};

Vecteur::~Vecteur()
{
}

int Vecteur::getNbrVecteur() const
{
    return nbrVecteur;
}

bool Vecteur::compare(Vecteur &v) const
{
    if (this->x == v.x && this->y == v.y && this->z == v.z)
    {
        return true;
    }
    return false;
}

bool Vecteur::compare(Vecteur *v) const
{
    if (this->x == v->x && this->y == v->y && this->z == v->z)
    {
        return true;
    }
    return false;
}

Vecteur Vecteur::oppose() const
{
    return Vecteur(this->x * -1, this->y * -1, this->z * -1);
}

Vecteur *Vecteur::oppose() const
{
    return Vecteur(this->x * -1, this->y * -1, this->z * -1);
}