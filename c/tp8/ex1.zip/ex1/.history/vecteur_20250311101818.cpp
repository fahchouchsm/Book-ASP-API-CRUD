#include "vecteur.h"
#include <iostream>

using namespace std;

Vecteur::Vecteur(int x, int y, int z) {
    this.x
};