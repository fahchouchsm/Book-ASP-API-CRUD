#ifndef VECTEUR_H
#define VECTEUR_H

class Vecteur
{
private:
    float x, y, z;

public:
    Vecteur(float = 0, float = 0, float = 0);
    Vecteur();
    static int nbrVecteur;
    ~Vecteur();
    int nbrVecteur();
};

#endif
