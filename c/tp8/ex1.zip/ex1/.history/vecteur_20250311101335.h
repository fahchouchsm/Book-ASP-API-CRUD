

class vecteur
{
}