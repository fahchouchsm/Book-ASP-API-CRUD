#ifndef VECTEUR_H
#define VECTEUR_H

class Vecteur
{
private:
    float x, y, z;

public:
    Vecteur(float x, float y, float z);
    Vecteur();
};

#endif
