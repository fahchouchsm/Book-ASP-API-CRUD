#include "Vecteur.h"
#include <iostream>
#include <cmath>
#include <cstring>

using namespace std;

int Vecteur::nbrVecteur = 0;

Vecteur::Vecteur(const float x, const float y, const float z, const char *nom)
{
    this->x = x;
    this->y = y;
    this->z = z;
    this->nom = new char[strlen(nom) + 1];
    strcpy(this->nom, nom);
    nbrVecteur++;
};

Vecteur::Vecteur(const Vecteur &v)
{
    x = v.x;
    y = v.y;
    z = v.z;
    this->nom = new char[strlen(v.nom) + 1];
    strcpy(this->nom, nom);
}

Vecteur::~Vecteur()
{
}

int Vecteur::getNbrVecteur() const
{
    return nbrVecteur;
}

bool Vecteur::compare(Vecteur &v) const
{
    if (this->x == v.x && this->y == v.y && this->z == v.z)
    {
        return true;
    }
    return false;
}

bool Vecteur::compare(Vecteur *v) const
{
    if (this->x == v->x && this->y == v->y && this->z == v->z)
    {
        return true;
    }
    return false;
}
// Oppose by Value
Vecteur Vecteur::oppose() const
{
    return Vecteur(-x, -y, -z, nom); // Return a new Vecteur by value
}

// Oppose by Pointer (Remember to delete later!)
Vecteur *Vecteur::opposep() const
{
    return new Vecteur(-x, -y, -z, nom);
}

// Oppose by Reference (Static object)
Vecteur &Vecteur::opposer() const
{
    static Vecteur v; // Keep it static for the function's lifetime
    v.x = -x;
    v.y = -y;
    v.z = -z;
    // If you want to make the "nom" field valid, you can handle it like this:
    v.nom = new char[strlen(nom) + 1]; // Dynamically allocate memory for nom
    strcpy(v.nom, nom);                // Copy the name to static object
    return v;
}

Vecteur &Vecteur::normMax(Vecteur &v)
{
    float norm1 = sqrt(x * x + y * y + z * z);
    float norm2 = sqrt(v.x * v.x + v.y * v.y + v.z * v.z);
    if (norm1 >= norm2)
    {
        return *this;
    }
    return v;
}

void Vecteur::affiche() const
{
    cout << nom << "(" << x << ", " << y << ", " << z << ")" << endl;
}
