#include "Vecteur.h"
#include <iostream>

using namespace std;

int main()
{
    // declaration
    Vecteur v1(3, 4, 5);
    Vecteur v2(6, 8, 10);
    Vecteur v3(3, 4, 5);

    cout << "Number of vectors created: " << v1.getNbrVecteur() << endl;

    cout << "v1 == v2? " << (v1.compare(v2) ? "Yes" : "No") << endl;
    cout << "v1 == v3? " << (v1.compare(v3) ? "Yes" : "No") << endl;

    cout << "v1 == v2 (ptr)? " << (v1.compare(&v2) ? "Yes" : "No") << endl;

    return 0;
}
