#include "Vecteur.h"

class Vecteur3 : public Vecteur
{
private:
    int h;

public:
    initialise3()
};