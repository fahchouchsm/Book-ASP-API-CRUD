#ifndef VECTEUR_H
#define VECTEUR_H

class Vecteur
{
private:
    float x, y, z;

public:
    Vecteur(float, float, float);
    Vecteur();
};

#endif
