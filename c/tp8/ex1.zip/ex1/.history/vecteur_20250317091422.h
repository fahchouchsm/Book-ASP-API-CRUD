#ifndef VECTEUR_H
#define VECTEUR_H

class Vecteur
{
private:
    float x, y, z;

public:
    Vecteur(const float = 0, const float = 0, const float = 0);
    ~Vecteur();
    void declacrede(const float &, const float &, const float &);
    bool compare(Vecteur &) const;
    bool compare(Vecteur *) const;
    int getNbrVecteur() const;
    static int nbrVecteur;
};

#endif
