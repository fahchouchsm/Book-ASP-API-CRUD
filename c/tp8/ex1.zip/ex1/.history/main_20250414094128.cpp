#include "Vecteur3.h"
#include <iostream>

using namespace std;

int main()
{
    // Vecteur a(3, 4, 5, "a"), *b;
    // Vecteur c = a;
    // b = new Vecteur(1, 2, 3, "b");
    // a = c;
    // a.affiche();
    // c.affiche();
    // b->affiche();
    // c = a + *b;
    // a = *b * 3;
    // a = 100 * a;
    // a.affiche();
    // delete b;

    return 0;
}
