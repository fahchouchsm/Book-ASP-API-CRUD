#ifndef VECTEUR_H
#define VECTEUR_H

class Vecteur
{
private:
    float x, y, z;
    char *nom;

public:
    Vecteur(const float = 0, const float = 0, const float = 0, const char * = "f");
    // constructeure de copy
    Vecteur(const Vecteur &);
    // operateur d'affectation
    Vecteur &operator=(const Vecteur &);
    // operateur de +
    Vecteur &operator+(const Vecteur &);
    // operateur de *
    Vecteur &operator*(const float &);
    // disctructeur
    ~Vecteur();
    void declacrede(const float &, const float &, const float &);
    bool compare(Vecteur &) const;
    bool compare(Vecteur *) const;
    // ex2
    Vecteur oppose() const;
    Vecteur *opposep() const;
    Vecteur &opposer() const;

    Vecteur &normMax(Vecteur &);
    Vecteur &normMax(Vecteur *);
    Vecteur *normMaxP(Vecteur &);
    void affiche() const;
    int getNbrVecteur() const;
    static int nbrVecteur;
};

#endif