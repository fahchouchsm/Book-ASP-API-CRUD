#include "vecteur.h"
#include <iostream>

using namespace std;

int main()
{
    // ✅ Create Vecteur objects
    Vecteur v1(3, 4, 5);
    Vecteur v2(6, 8, 10);
    Vecteur v3(3, 4, 5); // Same as v1 to test compare

    cout << "🔹 Number of vectors created: " << v1.getNbrVecteur() << endl;

    // ✅ Test compare (by reference)
    cout << "🔍 v1 == v2? " << (v1.compare(v2) ? "✅ Yes" : "❌ No") << endl;
    cout << "🔍 v1 == v3? " << (v1.compare(v3) ? "✅ Yes" : "❌ No") << endl;

    // ✅ Test compare (by pointer)
    cout << "🔍 v1 == v2 (ptr)? " << (v1.compare(&v2) ? "✅ Yes" : "❌ No") << endl;

    // ✅ Test oppose (return by value)
    Vecteur vOppose = v1.oppose();
    cout << "➖ Opposite of v1: (" << vOppose.x << ", " << vOppose.y << ", " << vOppose.z << ")" << endl;

    // ✅ Test opposep (return by pointer)
    Vecteur *vOpposeP = v1.opposep();
    cout << "➖ Opposite (pointer) of v1: (" << vOpposeP->x << ", " << vOpposeP->y << ", " << vOpposeP->z << ")" << endl;
    delete vOpposeP; // ⚠️ Avoid memory leak

    // ✅ Test opposer (return by reference)
    Vecteur &vOpposer = v1.opposer();
    cout << "➖ Opposite (ref) of v1: (" << vOpposer.x << ", " << vOpposer.y << ", " << vOpposer.z << ")" << endl;

    // ✅ Test normMax (by reference)
    Vecteur &vMaxRef = v1.normMax(v2);
    cout << "📏 Vector with max norm (ref): (" << vMaxRef.x << ", " << vMaxRef.y << ", " << vMaxRef.z << ")" << endl;

    // ✅ Test normMaxP (by pointer)
    Vecteur *vMaxPtr = v1.normMaxP(v2);
    cout << "📏 Vector with max norm (ptr): (" << vMaxPtr->x << ", " << vMaxPtr->y << ", " << vMaxPtr->z << ")" << endl;

    return 0;
}
