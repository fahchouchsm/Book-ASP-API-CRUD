#include "Vecteur.h"
#include <iostream>

using namespace std;

int main()
{
    // declaration
    Vecteur a(3, 4, 5, "a"), *b;
    // initialisation a la declaration au cours de creation
    Vecteur c = a;
    b = new Vecteur(1, 2, 3, "b");
    a = c;
    a.affiche();
    c.affiche();
    b->affiche();
    delete b;
    return 0;
}
