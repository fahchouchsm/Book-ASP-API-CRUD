#ifndef VECTEUR_H
#define VECTEUR_H

class Vecteur
{
private:
    float x, y, z;

public:
    Vecteur(const float = 0, const float = 0, const float = 0);
    Vecteur();
    int getNbrVecteur() const;
    static int nbrVecteur;
    ~Vecteur();
};

#endif
