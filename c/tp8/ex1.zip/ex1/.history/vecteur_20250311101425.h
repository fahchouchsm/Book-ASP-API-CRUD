#ifndef VECTEUR_H
#define VECTEUR_H

class vecteur
{
private:
    float x, y, z;
};

#endif
