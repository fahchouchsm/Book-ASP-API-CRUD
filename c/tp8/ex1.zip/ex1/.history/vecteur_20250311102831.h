#ifndef VECTEUR_H
#define VECTEUR_H

class Vecteur
{
private:
    float x, y, z;

public:
    Vecteur(float = 0, float = 0, float = 0);
    Vecteur();
    int nbrVecteur();
    static int nbrVecteur;
    ~Vecteur();
};

#endif
