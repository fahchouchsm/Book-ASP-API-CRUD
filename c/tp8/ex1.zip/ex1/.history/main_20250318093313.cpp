#include "Vecteur.h"
#include <iostream>

using namespace std;

int main()
{
    // declaration
    Vecteur a, *b;

    a.affiche();
    b = new Vecteur(1, 2, 3);

    if (b->compare())
    {
        /* code */
    }

    delete b;
    return 0;
}
