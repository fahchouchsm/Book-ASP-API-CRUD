#include "Chaine.h"
#include <cstring>
#include <iostream>

using namespace std;

Chaine::Chaine()
{
}

Chaine::Chaine(const char *c)
{
    int len = 0;
    while (c[len] != '\0')
    {
        len++;
    }

    adr = new char[len];
    for (int i = 0; i < len; i++)
    {
        adr[i] = c[i];
    }
}

int Chaine::taille() const
{
    int len = 0;
    while (adr[len] != '\0')
    {
        len++;
    }
    return len;