#include "Chaine.h"
#include <cstring>
#include <iostream>

using namespace std;

Chaine::Chaine()
{
    adr = new char[1];
    adr[0] = '\0';
}