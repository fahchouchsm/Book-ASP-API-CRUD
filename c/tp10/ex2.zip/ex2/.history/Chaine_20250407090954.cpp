#include "Chaine.h"
#include <cstring>
#include <iostream>

using namespace std;

Chaine::Chaine()
{
}

Chaine::Chaine(const char *c)
{
}