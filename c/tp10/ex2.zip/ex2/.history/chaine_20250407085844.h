// #ifdef CHAINE_H
#define CHAINE_H
#include <iostream>

using namespace std;

class chaine
{
private:
    char *adr;

public:
    chaine()
};

// #endif