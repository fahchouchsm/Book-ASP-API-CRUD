#include "Chaine.h"
#include <cstring>
#include <iostream>

using namespace std;

Chaine::Chaine()
{
    adr = new char[20];
    adr[0] = '\0';
}

Chaine::Chaine(const char *c)
{
    int len = 0;
    while (c[len] != '\0')
    {
        len++;
    }

    adr = new char[len];
    for (int i = 0; i < len; i++)
    {
        adr[i] = c[i];
    }
}

Chaine::~Chaine()
{
    delete[] adr;
}

int Chaine::taille() const
{
    int len = 0;
    while (adr[len] != '\0')
    {
        len++;
    }
    return len;
}

void Chaine::affiche() const
{
}
void ajout(char, int)
{
    // TODO -
}